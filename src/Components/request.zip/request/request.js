import * as React from 'react';
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';
import Paper from '@mui/material/Paper';
import Box from '@mui/material/Box';
import Grid from '@mui/material/Grid';
import Navbar from "../navbar/Navbar";
import avatar from '../../assets/avatar5.png';
import background from '../../assets/dnAJUB.webp';
import Typography from "@mui/material/Typography";
import "./request.css";
import { Card, CardContent, CardMedia} from '@mui/material';
import { styled } from '@mui/material/styles';
import GroupIcon from '@mui/icons-material/Group';
import PersonIcon from '@mui/icons-material/Person';

const Item = styled(Paper)(({ theme }) => ({
    backgroundColor: theme.palette.mode === 'dark' ? '#1A2027' : '#fff',
    ...theme.typography.body2,
    padding: theme.spacing(1),
    textAlign: 'center',
    color: theme.palette.text.secondary,
  }));


function createData(name, calories, fat, carbs, protein) {
  return { name, calories, fat, carbs, protein };
}

const rows = [
  createData('Frozen yoghurt', "Technical Lead 13+ yrs | NodeJS | Angular | iOS | Android | Php | MVC | JS | JQuery |"),
  createData('Ice cream sandwich', 237, 9.0, 37, 4.3),
  createData('Eclair', 262, 16.0, 24, 6.0),
  createData('Cupcake', 305, 3.7, 67, 4.3),
  createData('Gingerbread', 356, 16.0, 49, 3.9),
];

function createData2(name, calories, fat, carbs, protein) {
    return { name, calories, fat, carbs, protein };
  }
  const cards = [
    createData2('Frozen yoghurt', "Technical Lead 13+ yrs"),
    createData2('Ice cream sandwich', "Technical Lead 13+ yrs"),
    createData2('Eclair', "Technical Lead 13+ yrs"),
    createData2('Cupcake', "Technical Lead 13+ yrs"),
    createData2('Gingerbread', "Technical Lead 13+ yrs"),
  ];

export default function BasicTable() {

    const [showAll, setShowAll] = React.useState(false);
    const visibleRows = showAll ? rows : rows.slice(0, 3);

    const handleSeeAllClick = () => {
        setShowAll(!showAll);
      };
  
  return (

<Box sx={{ flexGrow: 1, justifyContent: 'center', marginTop: '80px' }}>
      <Navbar />
      <Grid container spacing={3} sx={{ display: 'flex', marginTop: '0vh', margin: "0 3vw", width: "91vw" }} >

      <Grid item xs={12} md={12} lg={1}>
          {/* <div style={{ position: 'sticky', top: 100, zIndex: 1030 }} >

            <Item>
                <CardContent sx={{ display: 'flex', justifyContent: 'space-around' }}>

                  <div className='col-md-12'>
                    <Typography variant="subtitle1" sx={{ fontWeight: 'bold', display: 'flex' }}>
                    Manage my network
                    </Typography>
                    <Typography variant="subtitle1" sx={{ fontWeight: 'bold', display: 'flex', gap: '10px'}}>
                    <GroupIcon />
Connections
                    </Typography><Typography variant="subtitle1" sx={{ fontWeight: 'bold', display: 'flex',  gap: '10px'}}>
                        <PersonIcon/>
                    Following & Followers
                    </Typography>
                    
                   </div>
                </CardContent>
            </Item>
          </div> */}
        </Grid>
        <Grid item xs={12} md={12} lg={10}>
            <Item>
        <TableContainer component={Paper}>
        <Table sx={{ minWidth: 650 }} aria-label="simple table">
          <TableHead>
            <TableRow>
              <TableCell>Invitations</TableCell>
              <TableCell></TableCell>
              <TableCell></TableCell>
              <TableCell align="right">
                    <span onClick={handleSeeAllClick}>{showAll ? 'See Less' : 'See All'}</span>
                  </TableCell>              
            </TableRow>
          </TableHead>
          <TableBody>
                {visibleRows.map((row) => (
                  <TableRow
                    key={row.name}
                    sx={{ '&:last-child td, &:last-child th': { border: 0 } }}
                  >
                    <TableCell component="th" scope="row">
                      {row.calories ? (
                        <Typography align="left">{row.name}</Typography>
                      ) : (
                        <img src={row.name} alt={row.name} />
                      )}
                    </TableCell>
                    <TableCell align="right">
                      <Typography align="left">{row.name}</Typography>
                      <Typography align="left">{row.calories}</Typography>
                    </TableCell>
                    <TableCell align="right">
                      <button class="btn btn-outline-secondary">Ignore</button>
                    </TableCell>
                    <TableCell align="right">
                      <button class="btn btn-primary">Accept</button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
        </Table>
      </TableContainer>
      </Item>
      {/* <div className='col-md-4 mt-3'>
      <Item>

              {cards.map((card, index) => (
      <div key={index}>
        <CardMedia
          component="img"
          alt="Cover Image"
          src={background}
          className="cover-img1"
        />
        <div className="profilecard121">
          <img
            src={avatar}
            alt="Profile"
            className="profile-photocard121"
          />
        </div>
        <CardContent>
          <Typography variant="subtitle1" component="div" sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center' }}>
            <span>{card.name}</span>
          </Typography>
          <Typography className="d-flex justify-content-center" variant="subtitle1" component="div" sx={{ display: 'flex', padding: '2px', fontSize: "14px" }}>
            <span>{card.calories}</span>
          </Typography>
        </CardContent>
        <CardContent>
          <div className='p-3'>
            <button className="btn btn-primary">Content</button>
          </div>
        </CardContent>
      </div>
    ))}
            </Item>
            </div> */}
        </Grid>

        <Grid item xs={12} md={12} lg={1}>
       
        </Grid>
        <Grid item xs={12} md={12} lg={1}>
        <Grid container spacing={3} className='mt-3'>
      {cards.map((card, index) => (
        <Grid item xs={12} md={4} key={index}>
          <Item>
            <CardMedia
              component="img"
              alt="Cover Image"
              src={background}
              className="cover-img1"
            />
            <div className="profilecard121">
              <img
                src={avatar}
                alt="Profile"
                className="profile-photocard121"
              />
            </div>
            <CardContent>
              <Typography variant="subtitle1" component="div" sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center' }}>
                <span>{card.name}</span>
              </Typography>
              <Typography className="d-flex justify-content-center" variant="subtitle1" component="div" sx={{ display: 'flex', padding: '2px', fontSize: "14px" }}>
                <span>{card.calories}</span>
              </Typography>
            </CardContent>
            <CardContent>
              <div className='p-3'>
                <button className="btn btn-primary">Content</button>
              </div>
            </CardContent>
          </Item>
        </Grid>
      ))}
    </Grid>

        </Grid>
       
      </Grid>


    </Box>
  );
}
